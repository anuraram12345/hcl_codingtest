import React from 'react';
 class Navbar extends React.Component {
     render(){
         return (
           <nav className='nav-wrapper'>
               <div className="container">
                   <ul>
                       <li><a href="bikes">Shop</a></li>
                       <li><a href="bikes">cart</a></li> 
                   </ul>
               </div>
           </nav>
         )
     }
 }
 export default Navbar;
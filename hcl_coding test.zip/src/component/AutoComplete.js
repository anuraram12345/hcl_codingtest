/* eslint-disable no-use-before-define */
import React from 'react';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Checkbox from '@material-ui/core/Checkbox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CartIcon from '../images/usa.jpg';
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

class ComboBox extends React.Component  {
    constructor(props) {
        super(props);
        this.state = {
            continent: [],
            countries: [],
            images:[]
        };
        this.onTagsChange = this.onTagsChange.bind(this);
        this.onCountryChange = this.onCountryChange.bind(this);
        this.clearImages = this.clearImages.bind(this);
      }
    
      onTagsChange = (event, values) => {
     
        for (var i = 0; i < topCountries.length; i++) {
            if(topCountries[i].continent === values) {
                console.log(topCountries[i].countries);
                this.setState({
                    continent: values,
                    countries: topCountries[i].countries
                  });
            }
            
        }
        
      }
      clearImages= () => {
        this.setState({
            images: []
          });
      }
      onCountryChange = (event, values) => {
         console.log("country change")
         let im = this.state.images;
         this.state.images.push(
            <img src={CartIcon} alt="img" width="100" height="100"/>
         )
        this.setState({
            images: im
          });
        
      }
      render() {
        return <div style={{ width: 300 }}>Please Select a Continent
             <Autocomplete
        freeSolo
        options={topCountries.map(option => option.continent)}
        onChange={this.onTagsChange}
        renderInput={params => (
          <TextField {...params} label="Select Continent" width="300" margin="normal" variant="outlined" fullWidth />
        )}
      /><span>You selected {this.state.continent}</span>
      <div> Now  Select a Country
      <Autocomplete
      multiple
      id="checkboxes-tags-demo"
      options={this.state.countries}
      getOptionLabel={option => option.name}
      onChange= {this.onCountryChange}
      disableCloseOnSelect
      renderOption={(option, { selected }) => (
        <React.Fragment>
          <Checkbox
            icon={icon}
            checkedIcon={checkedIcon}
            style={{ marginRight: 8 }}
            checked={selected}
          />
          {option.name}
        </React.Fragment>
      )}
      style={{ width: 500 }}
      renderInput={params => (
        <TextField
          {...params}
          variant="outlined"
          label="Checkboxes"
          placeholder="Favorites"
          fullWidth
        />)}
        /><div id = "images">{this.state.images}
         
    </div> <button onClick={this.clearImages}>clearImages</button>
        </div>
        </div>;
      }
  
}
const topCountries =[
	{
		"continent": "Africa",
		"countries": [
			{
				"name": "Nigeria",
				"flag": "🇳🇬"
			},
			{
				"name": "Ethiopia",
				"flag": "🇪🇹"
			},
			{
				"name": "Egypt",
				"flag": "🇪🇬"
			},
			{
				"name": "DR Congo",
				"flag": "🇨🇩"
			},
			{
				"name": "South Africa",
				"flag": "🇿🇦"
			}
		]
	},
	{
		"continent": "America",
		"countries": [
			{
				"name": "USA",
				"flag": "🇺🇸"
			},
			{
				"name": "Brazil",
				"flag": "🇧🇷"
			},
			{
				"name": "Mexico",
				"flag": "🇲🇽"
			},
			{
				"name": "Colombia",
				"flag": "🇨🇴"
			},
			{
				"name": "Argentina",
				"flag": "🇦🇷"
			}
		]
	},
	{
		"continent": "Asia",
		"countries": [
			{
				"name": "China",
				"flag": "🇨🇳"
			},
			{
				"name": "India",
				"flag": "🇮🇳"
			},
			{
				"name": "Indonesia",
				"flag": "🇮🇩"
			},
			{
				"name": "Pakistan",
				"flag": "🇵🇰"
			},
			{
				"name": "Bangladesh",
				"flag": "🇧🇩"
			}
		]
	},
	{
		"continent": "Europe",
		"countries": [
			{
				"name": "Russia",
				"flag": "🇷🇺"
			},
			{
				"name": "Germany",
				"flag": "🇩🇪"
			},
			{
				"name": "UK",
				"flag": "🇬🇧"
			},
			{
				"name": "France",
				"flag": "🇫🇷"
			},
			{
				"name": "Italy",
				"flag": "🇮🇹"
			}
		]
	},
	{
		"continent": "Oceania",
		"countries": [
			{
				"name": "Australia",
				"flag": "🇦🇺"
			},
			{
				"name": "Papua New Guinea",
				"flag": "🇵🇬"
			},
			{
				"name": "New Zealand",
				"flag": "🇳🇿"
			},
			{
				"name": "Fiji",
				"flag": "🇫🇯"
			},
			{
				"name": "Solomon Islands",
				"flag": "🇸🇧"
			}
		]
	}
]


export default ComboBox;
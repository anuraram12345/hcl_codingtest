import React from 'react';
import './App.css';
import Autocomplete from './component/AutoComplete';

class FocusableInput extends React.Component {
  

  render() {
    
    return <div>
  
  <section>
   
    
    <article>
      <p>This App will help you to learn the flags around</p></article>
  </section>
  <Autocomplete  /></div>;
  }
}

export default FocusableInput;